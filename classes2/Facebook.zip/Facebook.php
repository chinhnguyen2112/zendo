<?php
 
// Lớp database
class FB
{

}

?>